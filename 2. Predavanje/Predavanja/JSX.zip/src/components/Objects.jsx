function Objects() {
  const user = {
    firstName: "John",
    lastName: "Doe",
    age: 25,
  };

  // Ako zelite vidit sta ove funkcije vracaju mozete odkomentirat console logove pa vidit u konzoli
  //   console.log(Object.keys(user));
  //   console.log(Object.values(user));
  //   console.log(Object.entries(user));
  return (
    <>
      <h2>Objects</h2>
      <h3>Keys</h3>
      {/* Prikazujemo samo kljuceve https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/keys */}
      {Object.keys(user).map((key) => (
        <p>{key}</p>
      ))}
      <h3>Values</h3>
      {/* Prikazujemo samo vrijednosti https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/values */}
      {Object.values(user).map((key) => (
        <p>{key}</p>
      ))}
      <h3>Entries</h3>
      {/* Prikazujemo oboje https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/entries */}
      {Object.entries(user).map(([key, value]) => (
        <p>
          The value of {key} is {value}
        </p>
      ))}
    </>
  );
}

export default Objects;
