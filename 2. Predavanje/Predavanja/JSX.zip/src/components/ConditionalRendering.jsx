function ConditionalRendering() {
  const isVisible = true;

  const state = "ready";
  //   const state = "pending";
  //   const state = 'complete'
  //   const state = "error-occurred";

  const statusMap = {
    ready: "Ready to do something",
    pending: "Loading...",
    complete: "Completed!",
    // U realnoj situaciji bi bolji kljuc bia samo "error", ali cisto da vidite da se
    // i kompleksniji stringovi mogu napisat kao kljucevi objekta
    "error-occurred": "Something went wrong!",
  };

  return (
    <>
      <h2>Conditional Rendering</h2>
      <h3>Regular booleans</h3>
      {/* Koristenje AND uvjeta https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Logical_AND */}
      {isVisible && <p> Ovo će se prikazat</p>}
      {/* Koristenje OR uvjeta  https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Logical_OR */}
      {isVisible || <p> Ovo neće</p>}
      {/* Koristenje AND uvjeta i NOT operatora  https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Logical_NOT */}
      {!isVisible && <p> Ovo neće</p>}
      {/* Koristenje ternarnog operatora https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Conditional_Operator */}
      {isVisible ? <p> Ovo će se prikazat</p> : <p> Ovo neće</p>}
      {/* Koristenje "mape" https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Property_accessors */}
      <h3>Using a map</h3>
      {statusMap[state]}
    </>
  );
}

export default ConditionalRendering;
