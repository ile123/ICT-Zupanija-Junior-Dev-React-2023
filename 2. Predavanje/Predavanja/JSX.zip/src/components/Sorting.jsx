function Sorting() {
  const numbers = [4, 3, 6, 2, 3, 1];

  const users = [
    {
      name: "User 1",
      isAdmin: true,
    },
    {
      name: "User 4",
      isAdmin: false,
    },

    {
      name: "User 3",
      isAdmin: true,
    },
    {
      name: "User 2",
      isAdmin: false,
    },
  ];

  const compareUsersByName = (userA, userB) => {
    const nameA = userA.name.toUpperCase(); // ignore upper and lowercase
    const nameB = userB.name.toUpperCase(); // ignore upper and lowercase
    if (nameA < nameB) {
      return -1;
    }
    if (nameA > nameB) {
      return 1;
    }

    // names must be equal
    return 0;
  };

  return (
    <>
      <h2>Sorting</h2>
      <h3>Basic</h3>
      {/* Uvijek prvo sortiramo pa onda mapiramo https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/sort */}
      {numbers.sort().map((number) => (
        <p>{number}</p>
      ))}
      {/* Konkretni primjer kad imamo niz objekata i zelimo sortirat po specificnom polju https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/sort#sorting_array_of_objects */}
      <h3>Sorting objects on a certain property</h3>
      {users.sort(compareUsersByName).map((user) => (
        <p>{user.name}</p>
      ))}
    </>
  );
}

export default Sorting;
