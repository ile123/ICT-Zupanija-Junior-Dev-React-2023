function Filtering() {
  const users = [
    {
      name: "User 1",
      isAdmin: true,
    },
    {
      name: "User 2",
      isAdmin: false,
    },
    {
      name: "User 3",
      isAdmin: true,
    },
    {
      name: "User 4",
      isAdmin: false,
    },
  ];

  return (
    <>
      <h2>Filtering</h2>
      <h3>Is admin</h3>
      {/* Uvijek prvo filtriramo pa onda mapiramo https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/filter */}
      {users
        .filter((user) => user.isAdmin)
        .map((user) => (
          <p>{user.name}</p>
        ))}
    </>
  );
}

export default Filtering;
