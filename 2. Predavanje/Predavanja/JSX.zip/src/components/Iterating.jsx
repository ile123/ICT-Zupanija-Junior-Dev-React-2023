function Iterating() {
  const users = [
    {
      name: "User 1",
      isAdmin: true,
    },
    {
      name: "User 2",
      isAdmin: false,
    },
  ];

  return (
    <>
      {/* Koristimo map jer on vraca vrijednost za svaki clan https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/map */}
      <h2>Iterating</h2>
      <h3>Just usernames</h3>
      {users.map((user, index) => {
        // Uvijek kad iteriramo, glavni tag koji vracamo mora imat postavljen key https://react.dev/learn/rendering-lists
        return <p key={index}>{user.name}</p>;
      })}
      <h3>Usernames and isAdmin</h3>
      {users.map((user, index) => {
        return (
          <p key={index}>
            {user.name} {user.isAdmin ? "✓" : "☓"}
          </p>
        );
      })}
      <h3>Whole objects</h3>
      <i>Useful for debugging</i>
      {users.map((user, index) => {
        return <p key={index}>{JSON.stringify(user)}</p>;
      })}
    </>
  );
}

export default Iterating;
