import "./App.css";
import ConditionalRendering from "./components/ConditionalRendering";
import Filtering from "./components/Filtering";
import Iterating from "./components/Iterating";
import Objects from "./components/Objects";
import Sorting from "./components/Sorting";

function App() {
  const datum = new Date();
  const a = 10;
  const b = 20;

  return (
    <div>
      <h1>Examples</h1>
      <ConditionalRendering />
      <Iterating />
      <Filtering />
      <Sorting />
      <Objects />
    </div>
  );
}

export default App;
