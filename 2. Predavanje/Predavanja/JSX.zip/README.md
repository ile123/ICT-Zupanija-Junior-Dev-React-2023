# JSX cheatsheet

Ovo je sve napisano sa obicnim varijablama, ali se koristi na identicni nacin ako koristite useState

Verzija node-a bi trebala bit 18.x.x

Za pokrenit, standardno ka i za svaki drugi react projekt

npm install
npm run dev

Komponente gledajte po redosljedu u kojem su pozvane u App.jsx, a ne po redosljedu po kojem se nalaze u components folderu

Opcenito korisni linkovi:

https://react.dev/
https://developer.mozilla.org/en-US/
https://css-tricks.com/tag/react/ (ovde ako trazite neku specificnu temu lakse je priko search bar-a)

Korisna ekstenzija:

Trazite po imenu VSCode-u (sa lijeve strane imate tab extensions - 4 kockice)

Name: ES7+ React/Redux/React-Native snippets
Id: dsznajder.es7-react-js-snippets
Description: Extensions for React, React-Native and Redux in JS/TS with ES7+ syntax. Customizable. Built-in integration with prettier.
Version: 4.4.3
Publisher: dsznajder
VS Marketplace Link: https://marketplace.visualstudio.com/items?itemName=dsznajder.es7-react-js-snippets

Ako ste vidili da se meni formatira kod kad opalin save, to mozete postavit u opcijama VSCode-a "Format On Save"
